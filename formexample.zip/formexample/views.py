from django.shortcuts import render

def index(request):
	return render(request,"formexample/index.html")
def addlogic(request):
	a = request.GET["txtnum1"]
	b = request.GET["txtnum2"]
	c = int(a)+int(b)
	return render(request,"formexample/index.html",{'r':c})

def fact(request):
    if request.method=="POST":
        num = int(request.POST["txtnum1"])
        s=""
        f=1
        for i in range(num,0,-1):
           f=f*i
           s = "result is "+str(f)
        return render(request,"formexample/fact.html",{'res':s})
    return render(request,"formexample/fact.html")

    

def fibo(request):
    if request.method=="POST":
        num = int(request.POST["txtnum"])
        a=-1
        b=1
       # s = " "
        s =[]
        for i in range(1,num):
            c=a+b
           # s = s+str(c)
            s.append(c)
            a=b
            b=c
        return render(request,"formexample/fibo.html",{"res":s})    

    return render(request,"formexample/fibo.html")    


